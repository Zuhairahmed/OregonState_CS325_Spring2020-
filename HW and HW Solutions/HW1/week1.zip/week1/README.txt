To compile:
1. insertSort.cpp input into terminal: g++ insertSort.cpp -o insert
2. mergeSort.cpp input into terminal: g++ mergeSort.cpp -o merge

3. insertTime.cpp input into terminal: g++ insertTime.cpp -o insert
4. mergeTime.cpp input into terminal: g++ mergeTime.cpp -o merge

