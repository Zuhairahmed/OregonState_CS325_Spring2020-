/*******************************
 * Author: Zuhair Ahmed
 * Date Created: 4/5/2020
 * Filename: insertSort.cpp 
 * Overview: This program sorts unsorted list of numbers via Insertion Sort 
 * Input: "data.txt" file with first element being length followed by
 *        unsorted numbers  
 * Output: Sorted list of numbers back to "insert.out" file 
 * *****************************/

#include <iostream>
#include <fstream>
#include <cstdlib>

void print(int* array, int size); 
void insertionSort(int* array, int size); 

int main() 
{
   int n; // number of unsorted elements from data.txt file 
   const int MAX = 9999; 
   int arr[MAX];
   
   std::fstream myFile;
   myFile.open ("data.txt");
   if (myFile.fail()) //check to ensure file is avalible to open
   {
      std::cout << "Unable to open file!" << std::endl;
      exit(1); // terminate with error
   }
   else 
   {
       myFile >> n; //input length of unsorted list into n
       for (int i = 0; i < n; i++) //input remaining elements into array
            myFile >> arr[i]; 
   }
    
   std::cout << "Array before Sorting: ";
   print(arr, n);
   insertionSort(arr, n);
   
   std::cout << "Array after Sorting: ";
   print(arr, n);
   
   myFile.close(); 
   return 0;
}

void print(int *array, int size) 
{
   for(int i = 0; i < size; i++) //loop around array and output each element
      std::cout << array[i] << " ";
      
   std::cout << std::endl;
}

void insertionSort(int *array, int size) 
{
   int key, j;
   for(int i = 1; i < size; i++) 
   {
      key = array[i]; //set key equal to first element which is now sort half of array 
      j = i;
      while((j > 0) && (array[j-1] > key)) //while element is is > than key
      {
         array[j] = array[j-1]; //swap
         j--;
      }
      
      array[j] = key; //advance key to next element right of sorted array   
   }
}