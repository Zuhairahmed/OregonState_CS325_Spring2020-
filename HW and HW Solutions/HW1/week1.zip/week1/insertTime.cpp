/*******************************
 * Author: Zuhair Ahmed
 * Date Created: 4/5/2020
 * Filename: insertTime.cpp 
 * Overview: This program sorts unsorted list of numbers via Insertion Sort 
 * Input: Random integers from 0 to 10,000  
 * Output: Array size n and run time to terminal  
 * *****************************/

#include <iostream>
#include <cstdlib> 
#include <cstdio>
#include <ctime> 

void print(int* array, int size); 
void insertionSort(int* array, int size); 

int main() 
{
   const int MAX = 10000;
   int arrLength = 100000;
   int arr[arrLength];
   
   srand(time(NULL)); //seed random number 
   
   //fill array with random values
   for (int i = 0; i < arrLength; i++)
      arr[i] = rand() % MAX; 
    
 //  std::cout << "Array before Sorting: ";
//   print(arr, arrLength);
 //  std::cout << std::endl;
   
   std::clock_t start;
   start = std::clock();
   insertionSort(arr, arrLength); //sort array!
   
   std::cout << "Array after Sorting \n";
//   print(arr, arrLength);
   double duration = (std::clock() - start) / (double) CLOCKS_PER_SEC;
    
   std::cout << "Array Length is: " << arrLength << std::endl;
   std::cout << "Sorting took me via Insertion Sort: " << duration << " seconds"; 
   std::cout << std::endl; 
   
   return 0;
}

void print(int *array, int size) 
{
   for(int i = 0; i < size; i++) //loop around array and output each element
      std::cout << array[i] << " ";
   
   std::cout << std::endl;
}

void insertionSort(int *array, int size) 
{
   int key, j;
   for(int i = 1; i < size; i++) 
   {
      key = array[i]; //set key equal to first element which is now sort half of array 
      j = i;
      while((j > 0) && (array[j-1] > key)) //while element is is > than key
      {
         array[j] = array[j-1]; //swap
         j--;
      }
      
      array[j] = key; //advance key to next element right of sorted array   
   }
}