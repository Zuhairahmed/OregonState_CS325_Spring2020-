/*******************************
 * Author: Zuhair Ahmed
 * Date Created: 4/5/2020
 * Filename: insertTime.cpp 
 * Overview: This program sorts unsorted list of numbers via Merge Sort 
 * Input: Random integers from 0 to 10,000  
 * Output: Array size n and run time to terminal  
 * *****************************/

#include <iostream>
#include <cstdlib> 
#include <cstdio>
#include <ctime> 

void print(int* array, int size); 
void mergeSort(int* array, int start, int end); 
void mergeHelper(int array[], int Firstindex, int mid, int Lastindex);

int main() 
{
   const int MAX = 10000;
   int arrLength = 100000;
   int arr[arrLength];
   
   srand(time(NULL)); //seed random number 
   
   //fill array with random values
   for (int i = 0; i < arrLength; i++)
      arr[i] = rand() % MAX; 
    
 //  std::cout << "Array before Sorting: ";
 //  print(arr, arrLength);
 //  std::cout << std::endl;
   
   std::clock_t start;
   start = std::clock();
   int beg = 0;
   int end = arrLength-1;
   mergeSort(arr, beg, end); //sort array!
   
   std::cout << "Array after Sorting \n";
//   print(arr, arrLength);
   double duration = (std::clock() - start) / (double) CLOCKS_PER_SEC;
    
   std::cout << "Array Length is: " << arrLength << std::endl;
   std::cout << "Sorting took me via Merge Sort: " << duration << " seconds"; 
   std::cout << std::endl; 
   
   return 0;
}

void print(int *array, int size) 
{
   for(int i = 0; i < size; i++) //loop around array and output each element
      std::cout << array[i] << " ";
      
   std::cout << std::endl;
}

void mergeSort(int* array, int start, int end) 
{
    if (start < end) 
    {
        int mid = start + (end - start)/2; //find middle index 
        
        mergeSort(array, start, mid); //recursively sort first half
        mergeSort(array, mid+1, end); //recursively sort second half
        
        mergeHelper(array, start, mid, end); //recursively merge two halves together
    }
}

void mergeHelper(int array[], int Firstindex, int mid, int Lastindex) 
{   
    //temp variables 
    int z;
    int y;
    int x;
    
    //define two halves of merged array
    int sub1 = mid - Firstindex + 1; 
    int sub2 =  Lastindex - mid; 
        
    int Second[sub2]; //temp array2
    int First[sub1];  //temp array1
            
    //push elements into temp array1
    for (x = 0; x < sub1; x++) 
        First[x] = array[Firstindex + x];
    //push elements into temp array2
    for (y = 0; y < sub2; y++) 
        Second[y] = array[mid + 1+ y]; 
        
    z = Firstindex; 
    y = 0;
    x = 0; 
    
    //while temp variable is less then temp array swap elements
    while (x < sub1 && y < sub2) 
    { 
        if (First[x] <= Second[y]) 
        { 
            array[z] = First[x]; 
            x++; 
        } 
        else
        { 
            array[z] = Second[y]; 
            y++; 
        } 
        z++; 
    } 
    while (x < sub1) 
    { 
        array[z] = First[x]; 
        z++;
        x++; 
    } 
    while (y < sub2) 
    { 
        array[z] = Second[y]; 
        z++;
        y++; 
    } 
} 