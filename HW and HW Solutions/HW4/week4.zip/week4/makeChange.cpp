/********************************************************
 * Author: Zuhair Ahmed (ahmedz@oregonstate.edu)
 * Date Created: 4/26/2020
 * Filename: makeChange.cpp 
 * Overview: This program is a modified version of the make change problem. Goal 
 *           is to find minimum denomination of coins for change while using a 
 *           greedy algorithm approach. 
 * Input: "data.txt" which consists of input values c (base), k (max exponent), 
 *        and n (change to make in cents)
 * Output: "change.txt"  
 ********************************************************/

#include<fstream>
#include<iostream>
#include<cstdio>
#include<cmath>

int main()
{
    const int MAX = 9999;
    int array[MAX]; // array to store coin denominations   

    //create input/output file variables + check error if files cannot open 
    std::ofstream outputFile;
    std::ifstream inputFile;
    inputFile.open("data.txt");
    if (!inputFile.is_open())
    {
        std::cout << "ERROR: FILE CANNOT OPEN" << std::endl; //output to console
        return 1;
    }
    outputFile.open("change.txt");
    if (!outputFile.is_open())
    {
        std::cout << "ERROR: FILE CANNOT OPEN" << std::endl; //output to console
        return 1;
    }

    while (!inputFile.eof())    
    { 
        int c; //base denomination of coins  
        int k; //max exponent to raise base to 
        int n; //total in cents to then break into change 
        int count; //count of each coin denomination required
    
        //store values from file into associated variables  
        inputFile >> c; 
        inputFile >> k; 
        inputFile >> n; 
        
        //calc each value of denomination and store into array 
        for(int x = 0; x <= k; x++)
            array[x] = pow(c, x); 
        
        //print summary of inputs from data.txt file 
        outputFile << "Data input: c = " << c << ", k = " << k << ", n = " << n << std::endl; 
        
        for(int y = k; y >= 0; y--)
        {
           count = n / array[y]; 
           n = n % array[y]; //adjusting value of n for remaining coin denominations 
           if(count != 0)
               outputFile << "Denomination: " << array[y] << " Quantity: " << count << std::endl; 
           else 
               outputFile << "Denomination: " << array[y] << " Quantity: " << "none" << std::endl;
       }
       
       outputFile << std::endl << std::endl; 
    }
   
    //close input/output files and exit main        
    inputFile.close();
    outputFile.close();
    return 0;
}
