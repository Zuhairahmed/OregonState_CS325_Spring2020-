Instructions to Compile and Run

Compile:
    input into terminal: g++ binPack.cpp
Run:
    input into terminal: ./a.out 