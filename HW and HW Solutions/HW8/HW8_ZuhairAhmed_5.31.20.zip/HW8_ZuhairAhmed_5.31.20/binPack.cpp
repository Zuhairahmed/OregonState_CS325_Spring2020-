/********************************************************
 * Author: Zuhair Ahmed (ahmedz@oregonstate.edu)
 * Date Created: 5/31/2020
 * Filename: binPack.cpp 
 * Overview: C++ Implemention of Problem #1 (HW Assignment #8)
 *           Program to solve bin packing problem by 3 different Greedy methods
 *           1) First-Fit; 2) First-Fit Decreasing; 3) Best-Fit
 * Input: bin.txt file  
 * Output: prints to console  
 ********************************************************/

#include <fstream> 
#include <iostream>
#include <algorithm>

int fitHelper(int array[], int numOfItems, int binCapacity);
int bestFit(int arr[], int n, int capacity);
int firstFit(int array[], int numOfItems, int binCapacity);


int main() 
{
    //open .txt file  
    std::ifstream inputFile;
    inputFile.open("bin.txt");
    
    //input # of test cases from .txt file
    int numOfTestCases = 0;
    inputFile >> numOfTestCases;
    
    //core for loop to calc First-Fit, First-Fit-Decreasing, and Best-Fit for 
    //each item
    for(int x = 0; x < numOfTestCases; x++) 
    {
        //input bin capacity and total # of item per each test case from .txt file
        int binCapacity;
        int numOfItems;
        inputFile >> binCapacity;
        inputFile >> numOfItems;
        
        //input weight of each item into array of size n from .txt file
        int array[numOfItems];
        for(int y = 0; y < numOfItems; y++) 
            inputFile >> array[y];
        
        //print test case # and calc/print each methodology to console 
        std::cout << "Test Case " << x+1 << " ";
        fitHelper(array, numOfItems, binCapacity);
    }
    
    //close and return 0 to exit main 
    inputFile.close();
    return 0;
}

//helper function to print each of First-Fit, First-Fit-Decreasing, and Best-Fit
int fitHelper(int array[], int numOfItems, int binCapacity) 
{
    //print and calc First-Fit 
    std::cout << "First Fit: " << firstFit(array, numOfItems, binCapacity) << ", ";
    
    //print and calc First-Fit-Decreasing 
    sort(array, array+numOfItems, std::greater<int>()); // leverage sort function in C++ std algorithim library
    std::cout << "First Fit Decreasing: " << firstFit(array, numOfItems, binCapacity) << ", "; 
    
    //print and calc Best-Fit
    int bestFitBins = bestFit(array, numOfItems, binCapacity);
    std::cout << "Best Fit: " << bestFitBins << std::endl; 
}

int bestFit(int array[], int numOfItems, int binCapacity) 
{
    //declare varibles to store bin count and array of remaining space in bins  
    int bins1 = 0; 
    int binRem[numOfItems]; 
    double test1 = 2.0; 
    
    //core for loop to calc best-fit methodology  
    for(int x = 0; x < numOfItems; x++) 
    {
        //declare min space and index of the best bin variables 
        int min1 = binCapacity + 1;
        int temp = 0;
        
         //find correct bin to add current item via gready algorithm 
        for(int y = 0; y < bins1; y++) 
        {
            if(binRem[y] >= array[x] && binRem[y] - array[x] < min1) 
            {
                temp = y;
                min1 = binRem[y] - array[x];
            }
        }
        test1++;
        
        // if no bin create a new one
        if(min1 == binCapacity + 1) 
        {
            binRem[bins1] = binCapacity - array[x];
            bins1++;
        }
        //else add to an exisiting bin and adjust remaning space 
        else
            binRem[temp] -= array[x];
    }
    test1++;
    
    //returns total # of bins required for best-fit methodology 
    return bins1;
}

int firstFit(int array[], int numOfItems, int binCapacity)
{
    //declare varibles to store bin count and array of total bins 
    int bins[numOfItems];
    int binCount1 = 0; 
        
    //core for loop to calc first-fit methodology 
    for(int x = 0; x < numOfItems; x++) 
    {
        int flag = 0;
        int y = 0;
        int temp = 1; 
                
        //find correct bin to add current item via gready algorithm 
        while(y != binCount1) 
        {
            if(bins[y] >= array[x])
            {
                bins[y] = bins[y] - array[x];
                flag = 1;
                break;
            }
            y++;
        }
        temp++;
    
        //if additional bin is required: add item to bin and binCount is incremented 
        if(flag == 0) 
        {
            bins[binCount1] = binCapacity - array[x];
            binCount1++;
        }
        temp--;
    }
    
    //returns total # of bins required for first-fit or first-fit decreasing methodologies 
    return binCount1; 
}