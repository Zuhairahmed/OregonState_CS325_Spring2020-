/********************************************************
 * Author: Zuhair Ahmed (ahmedz@oregonstate.edu)
 * Date Created: 5/17/2020
 * Filename: makeChange.cpp 
 * Overview: C++ Implemention of Problem #3 (HW #6)
 *           Program to find minimum of coins and amount of each from inputted 
 *           Change and Denominations amounts 
 * Input: user provides from console 
 * Output: prints to console  
 ********************************************************/

#include <iostream>
int main()
{
    //intialize amount to make change and count of denominations variables
    int n, d = 0;
    
    std::cout << "Input amount to make Change: "; //taking amount as input
    std::cin >> n;
    if(n <= 0) //check to ensure inputed make change is not less than 0
    {
        std::cout << "INPUT ERROR, SAFTELY EXITNG NOW! \n";
        return 1;
    }
    
    std::cout << "Enter the # of denominations: "; //taking number of denominations as input
    std::cin >> d;
    if(d <= 0) //check to ensure inputed # of denominations is not less than 0
    {
        std::cout << "INPUT ERROR, SAFTELY EXITNG NOW! \n";
        return 1;
    }
    
    //intialize arrays to keep count of each amount, and sum to store total coins
    int a[d], c[d];
    int sum = 0; 
    
    std::cout << "Enter the denominations in descending order (no commas) : ";
    for(int x = 0; x < d; x++)
        std::cin >> a[x]; //input all denominations into array
    
    //greedy alogrithim filling up from largest to smallest until sum = make change amount
    for(int x = 0; x < d; x++)
    {
        c[x] = n/a[x];
        sum = sum + c[x];
        n = n % a[x];
    }
    
    //print results 
    for(int x = 0; x < d; x++)
        std::cout << a[x] << " : " << c[x] << std::endl;


    return 0;
}