/*******************************
 * Author: Zuhair Ahmed (ahmedz@oregonstate.edu)
 * Date Created: 4/19/2020
 * Filename: shoppingSpree.cpp 
 * Overview: This program is a modified version of Knapsack problem. Goal 
 *           is to find which items each person can carry such that family 
 *           overall can maximize their total profit. 
 * Input: "shopping.txt" which consts of T test cases
 * Output: "results.txt"  
 * *****************************/

#include<fstream>
#include<iostream>

//Max and knapSack functions based on pseudo-code from 
//Introduction to Algorithms, 3rd Ed. (pages 366-370) 
//by Thomas H Cormen, Charles E Leiserson, Ronald L Rivest, Clifford Stein
int max(int x, int y) 
// finds max of 2 ints and returns largest 
{

     if (x > y)
          return x;
     else
          return y;
}

int knapsack(int W[], int P[], int N, int M)
// finds max price of items carried by a person each than carries max weight M
{
     int K[N + 1][M + 1]; //create double array of max items and weight
     for (int a = 0; a <= N; ++a)
     {
          for (int b = 0; b <= M; ++b)
          {
              if ((a == 0) || (b == 0)) //case 1 - both are empty
              {
                   K[a][b] = 0;
              }
              else if (W[a - 1] <= b) //case 2 - b greater 
              {
                   K[a][b] = max(P[a - 1] + K[a - 1][b - W[a - 1]], K[a - 1][b]);
              }
              else //case 3 - a greater 
              {
                   K[a][b] = K[a - 1][b];
              }
          }
     }
    
     return K[N][M];  //maximum item prices carried by person
}

int main()
{
    // item weights
     int W[100];     
     // item prices     
     int P[100];   
      // # items
     int N; 
     // # test cases
     int T;          
    // max weight carried
     int M = 0;      
     // # people per family   
     int F;          

    //create input/output file variables + check error if files cannot open 
     std::ofstream outputFile;
     std::ifstream inputFile;
     inputFile.open("shopping.txt");
     if (!inputFile.is_open())
     {
          std::cout << "ERROR: FILE CANNOT OPEN" << std::endl; //output to console
          return 1;
     }
     outputFile.open("results.txt");
     if (!outputFile.is_open())
     {
          std::cout << "ERROR: FILE CANNOT OPEN" << std::endl; //output to console
          return 1;
     }
     
     inputFile >> T; //input # of test cases from file into T
     
     for (int counter1 = 0; counter1 < T; ++counter1) //main sequence per test case 
     {
          inputFile >> N; //# of items

          for (int counter2 = 0; counter2 < N; ++counter2)
          {
              inputFile >> P[counter2]; //read price
              inputFile >> W[counter2]; //read weight
          }
          int maxTPrice = 0;

          inputFile >> F; //# of Family members

        //Leverage knapSack helper function to calc max items each member can carry
          for (int counter3 = 0; counter3 < F; counter3++)
          {
              inputFile >> M; //max weight per member 
              maxTPrice = maxTPrice + knapsack(W, P, N, M); //calc max total price 
          }
          
          // Write output results to file
          outputFile << "Test Case " << counter1+1 << std::endl;
          outputFile << "Total Price " << maxTPrice << std::endl;
          outputFile << "Member Items " << std::endl;
          for (int i = 1; i < F+1; ++i)
            outputFile << "   " << i <<": " << knapsack(W, P, N, M) << std::endl;
     }

     outputFile.close();
     inputFile.close();
     return 0;
}