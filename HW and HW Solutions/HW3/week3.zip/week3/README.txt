Instructions To Compile and Run

Compile
    input into terminal: g++ shoppingSpree.cpp
Run
    input into terminal: ./a.out