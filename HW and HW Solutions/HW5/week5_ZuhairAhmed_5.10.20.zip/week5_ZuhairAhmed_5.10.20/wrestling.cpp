/********************************************************
 * Author: Zuhair Ahmed (ahmedz@oregonstate.edu)
 * Date Created: 5/10/2020
 * Filename: wrestling.cpp 
 * Overview: Implemention of HW Problem #5c)
 *           Algorithm that determines whether it is possible to designate some
 *           of the wrestlers as Babyfaces and the remainder as Heels such that
 *           each rivalry is between a Babyface and a Heel. If it is possible
 *           to perform such a designation, your algorithm should produce it. 
 * Input: .txt file whose name must be inputed at run time
 * Output: prints to terminal  
 ********************************************************/
 
//included below necessary c++ std clases  
#include<fstream>
#include<iostream>
#include<cstdio>
#include<vector>
#include<map>
#include<cstring>

//BreadthFirstSearch function to be called after main function 
bool bfs(int position, int parentNode);

//Global int vector variable used in both main and bfs functions 
#define MAXSIZE 999999 
std::vector<int> adjMatrix[MAXSIZE]; //Vector of adjency matrix
bool visited[MAXSIZE];
int babyfaces[MAXSIZE];

//MUST include .txt file name after "./a.out" when running from terminal
int main(int argc, char* args[])
{
   int r; //number of rivals
   int n; //number of wrestlers 
   int u; //index value of rival1
   int v; //index value of rival2
      
   //flag to check if possible to designate some wresterls as Babyface and 
   //others as Heels
   bool possibleFlag = 1; 
   
   //create a map/hash table variable called data to store wresterls with counts
   std::map<std::string, int> data1;
   
   //string varibles to be used
   std::string babyname; 
   std::string rival1; 
   std::string rival2;
      
    //**START OF FILE INPUT OPERATIONS**  
       std::ifstream infile(args[1]); //input from user typing into terminal
       if (!infile) //error handling on file
       {
           std::cout << "ERROR CANNOT OPEN FILE!" << std::endl;
           return 0;
       }
       
       //input number of wrestlers from file 
       infile >> n;
       
       //array of strings to store names of length n+1
       std::string wrestlerNames[n + 1];
       
       //read the names and store in map hash table
       for (int x = 0; x < n; x++)
       {
           infile >> babyname;
           data1[babyname] = x;
           wrestlerNames[x] = babyname;
       }
       
       //input number of rivals from file
       infile >> r;
       
       //input rivalries listed in pairs from file 
       for (int x = 0; x < r; x++)
       {
           infile >> rival1 >> rival2;
           
           //index value of rival1
           u = data1[rival1];
           
           //index value of rival2
           v = data1[rival2];
           
           //including edges on to graph
           adjMatrix[u].push_back(v);
           adjMatrix[v].push_back(u);
       }

       infile.close();
   //**END OF FILE INPUT OPERATIONS**  
   
   //memset all wrestlers as heels at first
   memset(babyfaces, 0, sizeof babyfaces);
   
   //breathFirstSearch nodes are all nodes declared unvisited at first
   memset(visited, 0, sizeof visited);
   
   //set babyfaces values to null 
   babyfaces[0] = 0;

   //runs bfs function for connected components only 
   for (int x = 0; x < n; x++)
   {
       if (visited[x])
           continue;
   
       //call the function bfs().
       possibleFlag = bfs(x, 0);
   
       //if not bipartite the partitioning is impossible
       if (!possibleFlag)
           break;
   }
   
   if (!possibleFlag)
       std::cout << "No. Not Possible to designate between Babyface and Heels \n";
   else
   {
       //intialize vector string of faces1 and heels1
       std::vector<std::string> faces1;
       std::vector<std::string> heels1;

       for (int x = 0; x < n; x++)
       {
           //push names into babyfaces if true
           if (babyfaces[x])
               faces1.push_back(wrestlerNames[x]);
           //else push into heels
           else
               heels1.push_back(wrestlerNames[x]);
       }
       
       std::cout << "Yes" << std::endl;
       std::cout << "Babyfaces: ";
       
       //output to console names of babyfaces
       for (int x = 0; x < faces1.size(); x++)
           std::cout << faces1[x] << " ";
       std::cout << std::endl;
       
       //output to console names of babyfaces
       std::cout << "Heels: ";
       for (int x = heels1.size() - 1; x >= 0; x--)
           std::cout << heels1[x] << " ";
       std::cout << std::endl;
   }

   return 0;
}

// bfs function is BOOL and confirms if graph of rivalries is bipartite 
bool bfs(int position, int parentNode)
{
   //mark the position as visited
   visited[position] = 1;
   int value;
   
   //assign the node value different to its parent
   babyfaces[position] = 1 - babyfaces[parentNode];
   
   //iterate the adjacency matrix
   for (int x = 0; x < adjMatrix[position].size(); x++)
   {
       value = adjMatrix[position][x];
       
       //if the value is not visted call bfs recursively 
       if (!visited[value])
           bfs(value, position);
       else
       {
           //if two adjacent nodes have same value, graph cannot be bipartite
           if (babyfaces[value] == babyfaces[position])
               return false;
       }
   }
   
   return true;
}