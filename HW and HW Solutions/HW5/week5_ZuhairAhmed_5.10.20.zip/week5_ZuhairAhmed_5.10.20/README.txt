Instructions to Compile and Run

Compile:
    input into terminal: g++ wrestling.cpp
Run:
    input into terminal: ./a.out wrestler2.txt