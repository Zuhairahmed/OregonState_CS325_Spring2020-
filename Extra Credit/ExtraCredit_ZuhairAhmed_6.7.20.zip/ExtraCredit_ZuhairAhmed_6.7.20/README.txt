Instructions to Compile and Run

Compile:
    input into terminal: g++ extracredit.cpp
Run:
    input into terminal: ./a.out 