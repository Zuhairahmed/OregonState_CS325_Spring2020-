/********************************************************
 * Author: Zuhair Ahmed (ahmedz@oregonstate.edu)
 * Date Created: 6/7/2020
 * Filename: extracredit.cpp
 * Overview: Given a number N, write a code to print all positive 
 *           numbers less than N in which all adjacent digits 
 *           differ by 1. 
 * Input: user inputs value of N from console 
 * Output: prints to console  
 ********************************************************/
  
#include <iostream>
#include <algorithm>
int check(int n);

int main()
{
    int n;
    //prompt user for value of n
    std::cout << "Input positive interger value of N: \n";
    std::cin >> n;
    
    //input test to check n > 0
    if (n < 0)
    {
        std::cout << "Invalid input; exiting program now \n";
        exit(0);
    }
    
    //for loop to print cases where values less than n are jumper numbers
    for(int x = 0; x <= n; x++) //checks all values less than n
    {
        if(check(x)) //if returns 1 then print, else do no nothing
            std::cout << x << " ";
    }
    std::cout << std::endl;
    
    //exit main function and end program
    return 0;
}

//core function that solves Extra Credit problem
int check(int num)
{
    //start with second to last digit of num since if less than 10
    //will skip down to return 1 line which will print value
    int digit1 = num%10;
    //shift decimal value of num left by 1 digit
    num = num/10;  
    
    //case where n > 10, focus only on n%10 digit
    while(num)
    {
        int digit2 = num%10;
        //if current digit and left digit differ by anything other than 1
        //return back 0 which DOES NOT print out value
        if(abs(digit1-digit2) != 1) 
            return 0;
        
        //else change num and x value to next digit and check again
        num = num/10;
        digit1 = digit2;
    }
    
    //case where n < 10, will always return 1
    return 1;
}